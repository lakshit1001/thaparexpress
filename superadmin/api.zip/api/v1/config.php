<?php
/**
 * Database configuration
 */
define('DB_USERNAME', 'bookfoxi_tx1');
define('DB_PASSWORD', 'laxarsh6!');
define('DB_HOST', 'localhost');
define('DB_NAME', 'bookfoxi_tx');
?>
